package com.example.myapplication.repository

import com.example.myapplication.model.Hive
import com.example.myapplication.model.SprayAlert
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await
import com.google.firebase.firestore.ListenerRegistration
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlin.math.*

class FirebaseRepository {
    private val db = FirebaseFirestore.getInstance()
    private val hivesCollection = db.collection("hives")
    private val alertsCollection = db.collection("alerts")

    fun listenForAlerts(): Flow<List<SprayAlert>> = callbackFlow {
        val subscription = alertsCollection
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    close(error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val alerts = snapshot.toObjects(SprayAlert::class.java)
                    trySend(alerts)
                }
            }
        awaitClose { subscription.remove() }
    }

    suspend fun deleteHive(hiveId: String) {
        hivesCollection.document(hiveId).delete().await()
    }

    suspend fun saveHive(hive: Hive) {
        hivesCollection.document(hive.id.ifEmpty { hivesCollection.document().id }).set(hive).await()
    }

    suspend fun getAllHives(): List<Hive> {
        return hivesCollection.get().await().toObjects(Hive::class.java)
    }

    suspend fun createSprayAlert(alert: SprayAlert): List<Hive> {
        val alertId = alertsCollection.document().id
        val finalAlert = alert.copy(id = alertId)
        alertsCollection.document(alertId).set(finalAlert).await()

        // Find beekeepers within 2km
        val allHives = getAllHives()
        return allHives.filter { hive ->
            calculateDistance(alert.latitude, alert.longitude, hive.latitude, hive.longitude) <= 2.0
        }
    }

    private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
        val r = 6371 // Radius of the earth in km
        val dLat = Math.toRadians(lat2 - lat1)
        val dLon = Math.toRadians(lon2 - lon1)
        val a = (sin(dLat / 2) * sin(dLat / 2)) +
                (cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
                sin(dLon / 2) * sin(dLon / 2))
        val c = 2 * atan2(sqrt(a), sqrt(1 - a))
        return r * c
    }
}

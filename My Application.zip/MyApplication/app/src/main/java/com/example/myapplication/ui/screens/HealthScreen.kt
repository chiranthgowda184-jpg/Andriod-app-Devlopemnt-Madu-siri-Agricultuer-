package com.example.myapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.model.Hive
import com.example.myapplication.ui.theme.BrownWood
import com.example.myapplication.ui.theme.HoneyYellow
import com.example.myapplication.ui.theme.LeafGreen
import com.example.myapplication.ui.viewmodel.MainViewModel

data class HealthRecord(
    val hiveName: String,
    val status: String,
    val honeyYield: String,
    val date: String,
    val color: Color
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HealthScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val hives by viewModel.hives.collectAsState()
    var showAddLogDialog by remember { mutableStateOf(false) }
    
    if (showAddLogDialog) {
        AddInspectionDialog(
            hives = hives,
            onDismiss = { showAddLogDialog = false },
            onSave = { hiveId, health, honey ->
                viewModel.updateHiveStats(hiveId, health, honey)
                showAddLogDialog = false
            }
        )
    }

    // Map hives to records for UI
    val records = hives.map { hive ->
        HealthRecord(
            hiveName = "Hive #${hive.id.takeLast(4)}",
            status = hive.healthStatus,
            honeyYield = "${hive.honeyProduction} kg",
            date = "Oct 25, 2023", 
            color = when (hive.healthStatus) {
                "Excellent" -> LeafGreen
                "Good" -> HoneyYellow
                else -> Color(0xFFFF7043)
            }
        )
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { 
                    Text(
                        "Hive Health Log", 
                        fontWeight = FontWeight.Bold,
                        color = BrownWood
                    ) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrownWood)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddLogDialog = true },
                containerColor = HoneyYellow,
                contentColor = BrownWood
            ) {
                Icon(Icons.Default.Add, contentDescription = "Add Log")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    "Recent Inspections", 
                    fontWeight = FontWeight.ExtraBold, 
                    style = MaterialTheme.typography.headlineSmall,
                    color = BrownWood
                )
                Spacer(modifier = Modifier.height(8.dp))
            }
            
            items(records) { record ->
                HealthCard(record)
            }
            
            if (records.isEmpty()) {
                item {
                    Text(
                        "No hives found. Add hives in the Map screen first.",
                        modifier = Modifier.fillMaxWidth().padding(32.dp),
                        textAlign = TextAlign.Center,
                        color = Color.Gray
                    )
                }
            }
            
            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }
    }
}

@Composable
fun AddInspectionDialog(
    hives: List<Hive>,
    onDismiss: () -> Unit,
    onSave: (String, String, Double) -> Unit
) {
    var selectedHiveId by remember { mutableStateOf(hives.firstOrNull()?.id ?: "") }
    var healthStatus by remember { mutableStateOf("Excellent") }
    var honeyYield by remember { mutableStateOf("") }
    var expanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Add Inspection Log", fontWeight = FontWeight.Bold, color = BrownWood) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                // Hive Selection
                Box {
                    OutlinedButton(
                        onClick = { expanded = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "Select Hive: ${hives.find { it.id == selectedHiveId }?.id?.takeLast(4) ?: "None"}",
                            color = BrownWood
                        )
                    }
                    DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                        hives.forEach { hive ->
                            DropdownMenuItem(
                                text = { Text("Hive #${hive.id.takeLast(4)}") },
                                onClick = {
                                    selectedHiveId = hive.id
                                    expanded = false
                                }
                            )
                        }
                    }
                }

                // Health Status
                Text("Health Status:", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Excellent", "Good", "Needs Attention").forEach { status ->
                        FilterChip(
                            selected = healthStatus == status,
                            onClick = { healthStatus = status },
                            label = { Text(status) }
                        )
                    }
                }

                // Honey Yield
                OutlinedTextField(
                    value = honeyYield,
                    onValueChange = { if (it.all { char -> char.isDigit() || char == '.' }) honeyYield = it },
                    label = { Text("Honey Yield (kg)") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (selectedHiveId.isNotEmpty()) {
                        onSave(selectedHiveId, healthStatus, honeyYield.toDoubleOrNull() ?: 0.0)
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = HoneyYellow,
                    contentColor = BrownWood
                ),
                enabled = selectedHiveId.isNotEmpty() && honeyYield.isNotEmpty()
            ) {
                Text("Save Log")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        },
        shape = RoundedCornerShape(24.dp),
        containerColor = Color.White
    )
}

@Composable
fun HealthCard(record: HealthRecord) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(12.dp)
                    .background(record.color, RoundedCornerShape(6.dp))
            )
            Spacer(modifier = Modifier.width(16.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = record.hiveName,
                    fontWeight = FontWeight.Bold,
                    style = MaterialTheme.typography.titleMedium,
                    color = BrownWood
                )
                Text(
                    text = "Yield: ${record.honeyYield}",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = record.status,
                    fontWeight = FontWeight.SemiBold,
                    color = record.color,
                    style = MaterialTheme.typography.bodySmall
                )
                Text(
                    text = record.date,
                    style = MaterialTheme.typography.bodySmall,
                    color = Color.LightGray
                )
            }
        }
    }
}

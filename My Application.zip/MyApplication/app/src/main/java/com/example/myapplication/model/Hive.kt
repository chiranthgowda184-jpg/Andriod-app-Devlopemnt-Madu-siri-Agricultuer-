package com.example.myapplication.model

data class Hive(
    val id: String = "",
    val ownerId: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val healthStatus: String = "Good",
    val honeyProduction: Double = 0.0
)

package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val HoneyYellow = Color(0xFFFFD700)
val Amber = Color(0xFFFFBF00)
val BeeBlack = Color(0xFF2B2B2B)
val LeafGreen = Color(0xFF4CAF50)
val SoftHoney = Color(0xFFFFF9C4)
val BrownWood = Color(0xFF8B4513)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)

val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)

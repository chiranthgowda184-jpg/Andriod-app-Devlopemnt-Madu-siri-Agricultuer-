package com.example.myapplication.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.myapplication.model.Hive
import com.example.myapplication.model.SprayAlert
import com.example.myapplication.repository.FirebaseRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainViewModel : ViewModel() {
    private val repository = FirebaseRepository()
    
    private val _hives = MutableStateFlow<List<Hive>>(emptyList())
    val hives: StateFlow<List<Hive>> = _hives.asStateFlow()

    private val _isAlerting = MutableStateFlow(false)
    val isAlerting: StateFlow<Boolean> = _isAlerting.asStateFlow()

    private val _activeAlerts = MutableStateFlow<List<SprayAlert>>(emptyList())
    val activeAlerts: StateFlow<List<SprayAlert>> = _activeAlerts.asStateFlow()

    init {
        loadHives()
        listenForAlerts()
    }

    private fun listenForAlerts() {
        viewModelScope.launch {
            repository.listenForAlerts().collectLatest { alerts ->
                // Filter alerts from the last 4 hours
                val fourHoursAgo = System.currentTimeMillis() - (4 * 60 * 60 * 1000)
                _activeAlerts.value = alerts.filter { it.timestamp > fourHoursAgo }
            }
        }
    }

    fun deleteHive(hiveId: String) {
        viewModelScope.launch {
            repository.deleteHive(hiveId)
            loadHives()
        }
    }

    fun updateHiveStats(hiveId: String, health: String, honey: Double) {
        viewModelScope.launch {
            val existingHive = _hives.value.find { it.id == hiveId }
            if (existingHive != null) {
                val updatedHive = existingHive.copy(
                    healthStatus = health,
                    honeyProduction = honey
                )
                repository.saveHive(updatedHive)
                loadHives()
            }
        }
    }

    fun loadHives() {
        viewModelScope.launch {
            try {
                _hives.value = repository.getAllHives()
            } catch (e: Exception) {
                // Handle error
            }
        }
    }

    fun sendSprayAlert(lat: Double, lng: Double) {
        viewModelScope.launch {
            _isAlerting.value = true
            try {
                val alert = SprayAlert(
                    latitude = lat,
                    longitude = lng,
                    message = "Pesticide spraying scheduled for today within 2km!"
                )
                val notifiedHives = repository.createSprayAlert(alert)
                // In a real app, FCM would handle notifications to these specific hive owners
            } catch (e: Exception) {
                // Handle error
            } finally {
                _isAlerting.value = false
            }
        }
    }

    fun addHive(lat: Double, lng: Double) {
        viewModelScope.launch {
            val newHive = Hive(
                id = System.currentTimeMillis().toString(),
                latitude = lat,
                longitude = lng,
                healthStatus = "Excellent"
            )
            repository.saveHive(newHive)
            loadHives()
        }
    }
}

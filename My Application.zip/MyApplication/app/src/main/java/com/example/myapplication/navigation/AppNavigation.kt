package com.example.myapplication.navigation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.screens.DashboardScreen
import com.example.myapplication.ui.screens.HealthScreen
import com.example.myapplication.ui.screens.MapScreen
import com.example.myapplication.ui.screens.TipsScreen
import com.example.myapplication.ui.viewmodel.MainViewModel

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val viewModel: MainViewModel = viewModel()
    val isAlerting by viewModel.isAlerting.collectAsState()
    val activeAlerts by viewModel.activeAlerts.collectAsState()
    val hives by viewModel.hives.collectAsState()

    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") {
            DashboardScreen(
                isAlerting = isAlerting,
                activeAlerts = activeAlerts,
                totalHoney = hives.sumOf { it.honeyProduction },
                onNavigateToMap = { navController.navigate("map") },
                onNavigateToHealth = { navController.navigate("health") },
                onNavigateToTips = { navController.navigate("tips") },
                onSprayAlert = { 
                    viewModel.sendSprayAlert(12.9716, 77.5946)
                }
            )
        }
        composable("map") {
            MapScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("health") {
            HealthScreen(
                viewModel = viewModel,
                onBack = { navController.popBackStack() }
            )
        }
        composable("tips") {
            TipsScreen(onBack = { navController.popBackStack() })
        }
    }
}

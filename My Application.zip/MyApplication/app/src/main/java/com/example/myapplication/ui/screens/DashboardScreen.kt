package com.example.myapplication.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.myapplication.model.SprayAlert
import com.example.myapplication.ui.theme.BrownWood
import com.example.myapplication.ui.theme.HoneyYellow
import com.example.myapplication.ui.theme.LeafGreen

@Composable
fun DashboardScreen(
    isAlerting: Boolean = false,
    activeAlerts: List<SprayAlert> = emptyList(),
    totalHoney: Double = 0.0,
    onNavigateToMap: () -> Unit,
    onNavigateToHealth: () -> Unit,
    onNavigateToTips: () -> Unit,
    onSprayAlert: () -> Unit
) {
    var showConfirmation by remember { mutableStateOf(false) }
    var isFarmerMode by remember { mutableStateOf(false) }

    if (showConfirmation) {
        AlertDialog(
            onDismissRequest = { showConfirmation = false },
            title = { Text("Confirm Spray Alert") },
            text = { Text("This will notify all beekeepers within 2km that you are about to spray pesticides. Proceed?") },
            confirmButton = {
                Button(
                    onClick = {
                        onSprayAlert()
                        showConfirmation = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Red)
                ) {
                    Text("Send Alert", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { showConfirmation = false }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(24.dp),
            containerColor = Color.White
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.align(Alignment.End)
        ) {
            Text(if (isFarmerMode) "Farmer Mode" else "Beekeeper Mode", style = MaterialTheme.typography.labelMedium)
            Switch(
                checked = isFarmerMode,
                onCheckedChange = { isFarmerMode = it },
                modifier = Modifier.scale(0.7f),
                colors = SwitchDefaults.colors(checkedThumbColor = HoneyYellow)
            )
        }
        
        Spacer(modifier = Modifier.height(8.dp))

        if (activeAlerts.isNotEmpty()) {
            ActiveAlertBanner(activeAlerts.size)
            Spacer(modifier = Modifier.height(16.dp))
        }
        
        Text(
            text = "Madhu-Siri",
            style = MaterialTheme.typography.displaySmall.copy(
                fontWeight = FontWeight.ExtraBold,
                color = BrownWood
            ),
            modifier = Modifier.padding(vertical = 8.dp)
        )
        
        Text(
            text = "Bee-Farmer Harmony",
            style = MaterialTheme.typography.titleMedium,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 24.dp)
        )

        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
            shape = RoundedCornerShape(24.dp)
        ) {
            Row(
                modifier = Modifier.padding(24.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = HoneyYellow.copy(alpha = 0.2f),
                    shape = CircleShape,
                    modifier = Modifier.size(64.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text("🐝", fontSize = 32.sp)
                    }
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        if (isFarmerMode) "Farmer Dashboard" else "Welcome!", 
                        fontWeight = FontWeight.Bold, 
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        if (isFarmerMode) "Protect your neighbor's bees." 
                        else "Honey Collected: $totalHoney kg", 
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            DashboardButton(
                text = "Hive Map",
                icon = Icons.Default.LocationOn,
                color = HoneyYellow,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToMap
            )
            DashboardButton(
                text = "Health Log",
                icon = Icons.Default.HealthAndSafety,
                color = LeafGreen,
                modifier = Modifier.weight(1f),
                onClick = onNavigateToHealth
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            DashboardButton(
                text = "Safe Tips",
                icon = Icons.Default.Info,
                color = Color(0xFF42A5F5),
                modifier = Modifier.weight(1f),
                onClick = onNavigateToTips
            )
            DashboardButton(
                text = if (isAlerting) "Alerting..." else "Spray Alert",
                icon = Icons.Default.Warning,
                color = if (isAlerting) Color.Red else Color(0xFFFF7043),
                modifier = Modifier.weight(1f),
                onClick = { showConfirmation = true }
            )
        }
        
        Spacer(modifier = Modifier.weight(1f))
        
        Text(
            text = if (isFarmerMode) 
                "Alert beekeepers before spraying pesticides." 
                else "Check map to pin your hives and monitor health.",
            style = MaterialTheme.typography.bodySmall,
            color = Color.Gray,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(start = 32.dp, end = 32.dp, bottom = 16.dp)
        )
    }
}

@Composable
fun ActiveAlertBanner(count: Int) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFFFEBEE)),
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color.Red.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = Icons.Default.Warning,
                contentDescription = null,
                tint = Color.Red,
                modifier = Modifier.size(24.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(
                text = "$count Active Spray Alert(s) nearby! Close your hives for 4 hours.",
                color = Color.Red,
                fontWeight = FontWeight.Bold,
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
fun DashboardButton(
    text: String,
    icon: ImageVector,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        modifier = modifier.height(140.dp),
        color = color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(24.dp),
        border = androidx.compose.foundation.BorderStroke(2.dp, color.copy(alpha = 0.5f))
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(16.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(40.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = text,
                color = BrownWood,
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp,
                textAlign = TextAlign.Center
            )
        }
    }
}

package com.example.myapplication.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.BrownWood
import com.example.myapplication.ui.theme.HoneyYellow
import com.example.myapplication.ui.viewmodel.MainViewModel
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.*

import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import com.example.myapplication.model.Hive

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(viewModel: MainViewModel, onBack: () -> Unit) {
    val hives by viewModel.hives.collectAsState()
    var selectedHive by remember { mutableStateOf<Hive?>(null) }
    
    if (selectedHive != null) {
        AlertDialog(
            onDismissRequest = { selectedHive = null },
            title = { Text("Hive Details") },
            text = { Text("Hive ID: ${selectedHive?.id?.takeLast(4)}\nStatus: ${selectedHive?.healthStatus}\n\nDo you want to remove this hive pin?") },
            confirmButton = {
                TextButton(
                    onClick = {
                        selectedHive?.let { viewModel.deleteHive(it.id) }
                        selectedHive = null
                    },
                    colors = ButtonDefaults.textButtonColors(contentColor = Color.Red)
                ) {
                    Text("Delete Pin")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedHive = null }) {
                    Text("Close")
                }
            }
        )
    }

    val villageLocation = LatLng(12.9716, 77.5946)
    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(villageLocation, 15f)
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { 
                    Text("Hive Map", fontWeight = FontWeight.Bold, color = BrownWood) 
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = BrownWood)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.White.copy(alpha = 0.9f)
                )
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    val currentPos = cameraPositionState.position.target
                    viewModel.addHive(currentPos.latitude, currentPos.longitude)
                },
                containerColor = HoneyYellow,
                contentColor = BrownWood,
                icon = { Icon(Icons.Default.AddLocationAlt, contentDescription = null) },
                text = { Text("Pin Hive Here") },
                shape = RoundedCornerShape(16.dp)
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            GoogleMap(
                modifier = Modifier.fillMaxSize(),
                cameraPositionState = cameraPositionState,
                uiSettings = MapUiSettings(zoomControlsEnabled = false)
            ) {
                hives.forEach { hive ->
                Marker(
                    state = MarkerState(position = LatLng(hive.latitude, hive.longitude)),
                    title = "Hive ID: ${hive.id.takeLast(4)}",
                    snippet = "Tap for details",
                    onClick = {
                        selectedHive = hive
                        true
                    }
                )
            }
            }
            
            // Helper text overlay
            Card(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White.copy(alpha = 0.8f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text(
                    "Center map on your hive and tap 'Pin Hive'",
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                    style = MaterialTheme.typography.bodySmall,
                    color = BrownWood
                )
            }
        }
    }
}

package com.example.myapplication.model

data class SprayAlert(
    val id: String = "",
    val farmerId: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val message: String = "Pesticide spraying scheduled for today."
)
